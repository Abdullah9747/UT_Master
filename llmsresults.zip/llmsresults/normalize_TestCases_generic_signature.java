import org.junit.Test;
import static org.junit.Assert.*;

public class BTaTHpzNNC_Test {

    @Test
    public void testCase1() {
        assertEquals(0, BTaTHpzNNC(0, 0));
    }

    @Test
    public void testCase2() {
        assertEquals(2, BTaTHpzNNC(1, 1));
    }

    @Test
    public void testCase3() {
        assertEquals(15, BTaTHpzNNC(10, 5));
    }

    @Test
    public void testCase4() {
        assertEquals(15, BTaTHpzNNC(5, 10));
    }

    @Test
    public void testCase5() {
        assertEquals(0, BTaTHpzNNC(-5, 5));
    }

    @Test
    public void testCase6() {
        assertEquals(0, BTaTHpzNNC(5, -5));
    }

    @Test
    public void testCase7() {
        assertEquals(-10, BTaTHpzNNC(-5, -5));
    }

    @Test
    public void testCase8() {
        assertEquals(5, BTaTHpzNNC(0, 5));
    }

    @Test
    public void testCase9() {
        assertEquals(5, BTaTHpzNNC(5, 0));
    }

    @Test
    public void testCase10() {
        assertEquals(Integer.MAX_VALUE + 1, BTaTHpzNNC(Integer.MAX_VALUE, 1));
    }

    @Test
    public void testCase11() {
        assertEquals(Integer.MIN_VALUE + 1, BTaTHpzNNC(Integer.MIN_VALUE, 1));
    }

    @Test
    public void testCase12() {
        assertEquals(-2, BTaTHpzNNC(Integer.MAX_VALUE, Integer.MAX_VALUE));
    }

    @Test
    public void testCase13() {
        assertEquals(-2, BTaTHpzNNC(Integer.MIN_VALUE, Integer.MIN_VALUE));
    }

    @Test
    public void testCase14() {
        assertEquals(Integer.MAX_VALUE + 1, BTaTHpzNNC(1, Integer.MAX_VALUE));
    }

    @Test
    public void testCase15() {
        assertEquals(Integer.MIN_VALUE + 1, BTaTHpzNNC(1, Integer.MIN_VALUE));
    }

    int BTaTHpzNNC(int GvfiHxoQFJ, int blBWvGxcXh) {
        return GvfiHxoQFJ + blBWvGxcXh;
    }
}
