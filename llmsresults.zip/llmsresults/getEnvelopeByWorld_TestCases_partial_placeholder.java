import org.junit.Test;
import org.geotools.geometry.jts.ReferencedEnvelope;
import static org.junit.Assert.*;

public class ExampleClassTest {

    private static class ExampleClass {
        public ReferencedEnvelope getEnvelopeByWorld(double FFkYjQEJQO) {
            return new ReferencedEnvelope(-FFkYjQEJQO, FFkYjQEJQO, -FFkYjQEJQO, FFkYjQEJQO, null);
        }
    }

    @Test
    public void testGetEnvelopeByWorld_Zero() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(0.0);
        assertEquals(0.0, envelope.getMinX(), 0.0001);
        assertEquals(0.0, envelope.getMaxX(), 0.0001);
        assertEquals(0.0, envelope.getMinY(), 0.0001);
        assertEquals(0.0, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_One() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(1.0);
        assertEquals(-1.0, envelope.getMinX(), 0.0001);
        assertEquals(1.0, envelope.getMaxX(), 0.0001);
        assertEquals(-1.0, envelope.getMinY(), 0.0001);
        assertEquals(1.0, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_TenPointFive() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(10.5);
        assertEquals(-10.5, envelope.getMinX(), 0.0001);
        assertEquals(10.5, envelope.getMaxX(), 0.0001);
        assertEquals(-10.5, envelope.getMinY(), 0.0001);
        assertEquals(10.5, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_NegativeOne() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(-1.0);
        assertEquals(1.0, envelope.getMinX(), 0.0001);
        assertEquals(-1.0, envelope.getMaxX(), 0.0001);
        assertEquals(1.0, envelope.getMinY(), 0.0001);
        assertEquals(-1.0, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_DoubleMaxValue() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(Double.MAX_VALUE);
        assertEquals(-Double.MAX_VALUE, envelope.getMinX(), 0.0001);
        assertEquals(Double.MAX_VALUE, envelope.getMaxX(), 0.0001);
        assertEquals(-Double.MAX_VALUE, envelope.getMinY(), 0.0001);
        assertEquals(Double.MAX_VALUE, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_DoubleMinValue() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(Double.MIN_VALUE);
        assertEquals(-Double.MIN_VALUE, envelope.getMinX(), 0.0001);
        assertEquals(Double.MIN_VALUE, envelope.getMaxX(), 0.0001);
        assertEquals(-Double.MIN_VALUE, envelope.getMinY(), 0.0001);
        assertEquals(Double.MIN_VALUE, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_NaN() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(Double.NaN);
        assertTrue(Double.isNaN(envelope.getMinX()));
        assertTrue(Double.isNaN(envelope.getMaxX()));
        assertTrue(Double.isNaN(envelope.getMinY()));
        assertTrue(Double.isNaN(envelope.getMaxY()));
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_PositiveInfinity() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(Double.POSITIVE_INFINITY);
        assertEquals(Double.NEGATIVE_INFINITY, envelope.getMinX(), 0.0001);
        assertEquals(Double.POSITIVE_INFINITY, envelope.getMaxX(), 0.0001);
        assertEquals(Double.NEGATIVE_INFINITY, envelope.getMinY(), 0.0001);
        assertEquals(Double.POSITIVE_INFINITY, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testGetEnvelopeByWorld_NegativeInfinity() {
        ExampleClass example = new ExampleClass();
        ReferencedEnvelope envelope = example.getEnvelopeByWorld(Double.NEGATIVE_INFINITY);
        assertEquals(Double.POSITIVE_INFINITY, envelope.getMinX(), 0.0001);
        assertEquals(Double.NEGATIVE_INFINITY, envelope.getMaxX(), 0.0001);
        assertEquals(Double.POSITIVE_INFINITY, envelope.getMinY(), 0.0001);
        assertEquals(Double.NEGATIVE_INFINITY, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }
}
