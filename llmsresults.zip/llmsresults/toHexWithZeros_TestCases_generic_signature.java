import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class PSkHvHNddLTest {

    @Test
    public void testPSkHvHNddL_0() {
        assertEquals("00", PSkHvHNddL((byte) 0));
    }

    @Test
    public void testPSkHvHNddL_16() {
        assertEquals("ff", PSkHvHNddL((byte) -1));
    }

    @Test
    public void testPSkHvHNddL_32() {
        assertEquals("0f", PSkHvHNddL((byte) 15));
    }

    @Test
    public void testPSkHvHNddL_64() {
        assertEquals("10", PSkHvHNddL((byte) 16));
    }

    private String PSkHvHNddL(byte BtkvDqVxb) {
        int LhZgYyNszR = BtkvDqVxb & 0xFF;
        String zJplRkWNqN = Integer.toHexString(LhZgYyNszR);
        if (zJplRkWNqN.length() == 1) {
            zJplRkWNqN = "0" + zJplRkWNqN;
        }
        return zJplRkWNqN;
    }
}
