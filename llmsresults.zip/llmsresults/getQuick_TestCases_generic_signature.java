mport org.junit.Test;
import static org.junit.Assert.assertEquals;

public class OkxinxQCoLTest {

    @Test
    public void testZGyCwmBOLX_0() {
        assertEquals(0.0, new Solution().okxinxQCoL(0), 0.000001);
    }

    @Test
    public void testZGyCwmBOLX_1() {
        assertEquals(1.0, new Solution().okxinxQCoL(1), 0.000001);
    }

    @Test
    public void testZGyCwmBOLX_3() {
        assertEquals(1.8333333333333333, new Solution().okxinxQCoL(3), 0.000001);
    }

    @Test
    public void testZGyCwmBOLX_negative1() {
        assertEquals(0.0, new Solution().okxinxQCoL(-1), 0.000001);
    }
}
