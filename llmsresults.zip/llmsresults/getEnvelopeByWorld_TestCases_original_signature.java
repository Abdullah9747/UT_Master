import org.junit.Test;
import static org.junit.Assert.*;
import org.geotools.geometry.jts.ReferencedEnvelope;
import org.opengis.referencing.crs.CoordinateReferenceSystem;

public class EnvelopeHelperTest {

    @Test
    public void testPositiveWidth() {
        EnvelopeHelper helper = new EnvelopeHelper();
        ReferencedEnvelope envelope = helper.getEnvelopeByWorld(10.0);
        assertEquals(-5.0, envelope.getMinX(), 1e-9);
        assertEquals(5.0, envelope.getMaxX(), 1e-9);
        assertEquals(-5.0, envelope.getMinY(), 1e-9);
        assertEquals(5.0, envelope.getMaxY(), 1e-9);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testZeroWidth() {
        EnvelopeHelper helper = new EnvelopeHelper();
        ReferencedEnvelope envelope = helper.getEnvelopeByWorld(0.0);
        assertEquals(0.0, envelope.getMinX(), 1e-9);
        assertEquals(0.0, envelope.getMaxX(), 1e-9);
        assertEquals(0.0, envelope.getMinY(), 1e-9);
        assertEquals(0.0, envelope.getMaxY(), 1e-9);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testSmallPositiveWidth() {
        EnvelopeHelper helper = new EnvelopeHelper();
        ReferencedEnvelope envelope = helper.getEnvelopeByWorld(0.001);
        assertEquals(-0.0005, envelope.getMinX(), 1e-9);
        assertEquals(0.0005, envelope.getMaxX(), 1e-9);
        assertEquals(-0.0005, envelope.getMinY(), 1e-9);
        assertEquals(0.0005, envelope.getMaxY(), 1e-9);
        assertNull(envelope.getCoordinateReferenceSystem());
    }

    @Test
    public void testLargePositiveWidth() {
        EnvelopeHelper helper = new EnvelopeHelper();
        ReferencedEnvelope envelope = helper.getEnvelopeByWorld(1000000.0);
        assertEquals(-500000.0, envelope.getMinX(), 1e-9);
        assertEquals(500000.0, envelope.getMaxX(), 1e-9);
        assertEquals(-500000.0, envelope.getMinY(), 1e-9);
        assertEquals(500000.0, envelope.getMaxY(), 1e-9);
        assertNull(envelope.getCoordinateReferenceSystem());
    }
}
