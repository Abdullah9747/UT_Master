import org.junit.Test;
import static org.junit.Assert.*;
import org.opengis.geometry.DirectPosition;
import org.opengis.referencing.crs.CoordinateReferenceSystem;

public class MyClassTest {

    private static class DirectPosition2D implements DirectPosition{
        private final double x;
        private final double y;
        private final CoordinateReferenceSystem crs;

        public DirectPosition2D(double x, double y, CoordinateReferenceSystem crs) {
            this.x = x;
            this.y = y;
            this.crs = crs;
        }
        @Override
        public int getDimension() {
            return 2;
        }

        @Override
        public CoordinateReferenceSystem getCoordinateReferenceSystem() {
            return crs;
        }

        @Override
        public double[] getDirectPosition() {
            return new double[]{x, y};
        }

        @Override
        public double getOrdinate(int dimension) throws IndexOutOfBoundsException {
            if (dimension == 0) return x;
            if (dimension == 1) return y;
            throw new IndexOutOfBoundsException("Dimension out of bounds: " + dimension);
        }

        @Override
        public void setOrdinate(int dimension, double value) throws IndexOutOfBoundsException {
            throw new UnsupportedOperationException("Setting ordinates is not supported.");
        }

        public double getX() {
            return x;
        }

        public double getY() {
            return y;
        }
    }

    private static class ReferencedEnvelope {
        private final double minX;
        private final double maxX;
        private final double minY;
        private final double maxY;
        private final CoordinateReferenceSystem crs;

        public ReferencedEnvelope(double minX, double maxX, double minY, double maxY, CoordinateReferenceSystem crs) {
            this.minX = minX;
            this.maxX = maxX;
            this.minY = minY;
            this.maxY = maxY;
            this.crs = crs;
        }

        public double getMinX() {
            return minX;
        }

        public double getMaxX() {
            return maxX;
        }

        public double getMinY() {
            return minY;
        }

        public double getMaxY() {
            return maxY;
        }

        public CoordinateReferenceSystem getCoordinateReferenceSystem() {
            return crs;
        }
    }

    static class MyClass {
        protected DirectPosition2D getWorldPos() {
            return null;
        }

        public ReferencedEnvelope getEnvelopeByWorld(double widthWorld) {
            if (widthWorld < 0) {
                throw new IllegalArgumentException("invalid value for widthWorld: " + widthWorld);
            }

            double halfw = widthWorld / 2;
            DirectPosition2D worldPos = getWorldPos();
            return new ReferencedEnvelope(
                    worldPos.getX() - halfw, worldPos.getX() + halfw,
                    worldPos.getY() - halfw, worldPos.getY() + halfw,
                    worldPos.getCoordinateReferenceSystem());
        }
    }

    private static class MockMyClass extends MyClass {
        private final double x;
        private final double y;
        private final CoordinateReferenceSystem crs;

        public MockMyClass(double x, double y, CoordinateReferenceSystem crs) {
            this.x = x;
            this.y = y;
            this.crs = crs;
        }
        @Override
        protected DirectPosition2D getWorldPos() {
            return new DirectPosition2D(x, y, crs);
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativeWidthWorld() {
        CoordinateReferenceSystem crs = null;
        MyClass myObject = new MockMyClass(0.0, 0.0, crs);
        myObject.getEnvelopeByWorld(-1.0);
    }

    @Test
    public void testPositiveWidthWorld() {
        CoordinateReferenceSystem crs = null;
        MockMyClass myObject = new MockMyClass(10.0, 5.0, crs);
        ReferencedEnvelope envelope = myObject.getEnvelopeByWorld(2.0);

        assertNotNull(envelope);
        assertEquals(9.0, envelope.getMinX(), 0.0001);
        assertEquals(11.0, envelope.getMaxX(), 0.0001);
        assertEquals(4.0, envelope.getMinY(), 0.0001);
        assertEquals(6.0, envelope.getMaxY(), 0.0001);
        assertNull(envelope.getCoordinateReferenceSystem());
    }
}
