import org.junit.Test;
import static org.junit.Assert.*;

public class ElapsedTest {

    @Test
    public void testPositiveElapsedTime() {
        assertEquals(10, elapsed(10, 20));
    }

    @Test
    public void testZeroElapsedTime() {
        assertEquals(0, elapsed(10, 10));
    }

    @Test
    public void testNegativeElapsedTime() {
        assertEquals(-10, elapsed(20, 10));
    }

    @Test
    public void testLargePositiveElapsedTime() {
        assertEquals(Long.MAX_VALUE, elapsed(0, Long.MAX_VALUE));
    }

    @Test
    public void testLargeNegativeElapsedTime() {
        assertEquals(-Long.MAX_VALUE, elapsed(Long.MAX_VALUE, 0));
    }

    private long elapsed(long started, long finished) {
        return finished - started;
    }
}
