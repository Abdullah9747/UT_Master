import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Calendar;
import java.util.TimeZone;

public class ExpireAtMonthTest {

    private long expireAtMonth(int addMonth, int atDay, int atHour, int atMin) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.add(Calendar.MONTH, addMonth);
        cal.set(Calendar.DAY_OF_MONTH, atDay);
        cal.set(Calendar.HOUR_OF_DAY, atHour);
        cal.set(Calendar.MINUTE, atMin);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    @Test
    public void testTC1() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month, 15, 12, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(0, 15, 12, 30);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC2() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month + 1, 1, 0, 0, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(1, 1, 0, 0);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC3() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year + 1, month, 31, 23, 59, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        expectedCal.add(Calendar.MONTH, 12 - month);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(12, 31, 23, 59);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC4() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month - 1, 1, 0, 0, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(-1, 1, 0, 0);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC5() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month, 31, 12, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

        int maxDay = expectedCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        expectedCal.set(Calendar.DAY_OF_MONTH, Math.min(31, maxDay));

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(0, 31, 12, 30);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC6() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);

        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month + 1, 1, 12, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        expectedCal.add(Calendar.MONTH, 1);

        int maxDay = expectedCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        expectedCal.set(Calendar.DAY_OF_MONTH, Math.min(31, maxDay));
        expectedCal.add(Calendar.MONTH, -1);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(1, 31, 12, 30);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC7() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);

        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month, 29, 12, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

         if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
             long expectedTimestamp = expectedCal.getTimeInMillis();
             long actualTimestamp = expireAtMonth(0, 29, 12, 30);
             assertEquals(expectedTimestamp, actualTimestamp);
         } else {
             expectedCal.set(year, month, 28, 12, 30, 0);
             expectedCal.set(Calendar.MILLISECOND, 0);
             long expectedTimestamp = expectedCal.getTimeInMillis();
             long actualTimestamp = expireAtMonth(0, 29, 12, 30);
             assertEquals(expectedTimestamp, actualTimestamp);
         }
    }

    @Test
    public void testTC8() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);

        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month + 1, 1, 12, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        expectedCal.add(Calendar.MONTH, 1);
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            expectedCal.set(Calendar.DAY_OF_MONTH, 29);
        }
        else {
            expectedCal.set(Calendar.DAY_OF_MONTH, 28);
        }
        expectedCal.add(Calendar.MONTH, -1);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(1, 29, 12, 30);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC9() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);

        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year + 2, month, 1, 0, 0, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);
        expectedCal.add(Calendar.MONTH, 24 - month);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(24, 1, 0, 0);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC10() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year - 1, month, 15, 12, 30, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(-12, 15, 12, 30);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC11() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month, 1, 0, 1, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(0, 1, 0, 1);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC12() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);
        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month, 1, 23, 59, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(0, 1, 23, 59);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC13() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        now.set(Calendar.DAY_OF_MONTH, now.getActualMaximum(Calendar.DAY_OF_MONTH));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);

        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month + 1, 1, 0, 0, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(1, 1, 0, 0);
        assertEquals(expectedTimestamp, actualTimestamp);
    }

    @Test
    public void testTC14() {
        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        now.set(Calendar.DAY_OF_MONTH, now.getActualMaximum(Calendar.DAY_OF_MONTH));
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH);

        Calendar expectedCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        expectedCal.set(year, month, 1, 0, 0, 0);
        expectedCal.set(Calendar.MILLISECOND, 0);

        long expectedTimestamp = expectedCal.getTimeInMillis();
        long actualTimestamp = expireAtMonth(0, 1, 0, 0);
        assertEquals(expectedTimestamp, actualTimestamp);
    }
}
