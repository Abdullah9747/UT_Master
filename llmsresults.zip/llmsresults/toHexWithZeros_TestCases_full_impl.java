import org.junit.Test;
import static org.junit.Assert.*;

public class ToHexWithZerosTest {

    // Assume there is a function toHex(byte b) available for testing.
    // Replace this with your actual toHex function or mock it.
    public static String toHex(byte b) {
        return Integer.toHexString(b & 0xFF).toUpperCase();
    }

    public static String toHexWithZeros(byte b) {
        if (b == 0)
            return "00";
        String s = toHex(b);
        if (s.length() == 1)
            return "0" + s;
        else
            return s;
    }

    @Test
    public void testByteZero() {
        assertEquals("00", toHexWithZeros((byte) 0));
    }

    @Test
    public void testBytePositiveSingleDigitHex() {
        assertEquals("0A", toHexWithZeros((byte) 10));
    }

    @Test
    public void testByteNegative() {
        assertEquals("FF", toHexWithZeros((byte) -1));
    }

    @Test
    public void testByteMaxValue() {
        assertEquals("7F", toHexWithZeros(Byte.MAX_VALUE));
    }

    @Test
    public void testByteMinValue() {
        assertEquals("80", toHexWithZeros(Byte.MIN_VALUE));
    }
}
