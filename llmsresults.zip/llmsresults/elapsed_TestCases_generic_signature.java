import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class AoqmaHaSfUTest {

    @Test
    public void testCase1() {
        assertEquals(6, aoqmaHaSfU(2, 3));
    }

    @Test
    public void testCase2() {
        assertEquals(0, aoqmaHaSfU(5, 0));
    }

    @Test
    public void testCase3() {
        assertEquals(-10, aoqmaHaSfU(-2, 5));
    }

    @Test
    public void testCase4() {
        assertEquals(-6, aoqmaHaSfU(2, -3));
    }

    @Test
    public void testCase5() {
        assertEquals(Long.MAX_VALUE, aoqmaHaSfU(Long.MAX_VALUE, 1));
    }

    @Test
    public void testCase6() {
        assertEquals(Long.MAX_VALUE, aoqmaHaSfU(1, Long.MAX_VALUE));
    }

    private long aoqmaHaSfU(long xzXsyIyuKg, long qRERvBYkaE) {
        long result = 0;
        while (qRERvBYkaE > 0) {
            if ((qRERvBYkaE & 1) == 1) {
                result += xzXsyIyuKg;
            }
            xzXsyIyuKg <<= 1;
            qRERvBYkaE >>= 1;
        }
        return result;
    }
}
