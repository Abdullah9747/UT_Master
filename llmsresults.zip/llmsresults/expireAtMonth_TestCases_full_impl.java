import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Calendar;

public class SolutionTest {

    public long expireAtMonth(int addMonth, int atDay, int atHour, int atMin) {
        long curTime = System.currentTimeMillis();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, addMonth);
        calendar.set(Calendar.DAY_OF_MONTH, atDay);
        calendar.set(Calendar.HOUR_OF_DAY, atHour);
        calendar.set(Calendar.MINUTE, atMin);
        long result = (calendar.getTimeInMillis() - curTime) / 1000;
        return result;
    }

    @Test
    public void testCase1() {
        long result = expireAtMonth(1, 15, 12, 30);
        assertTrue(result > 0);
    }

    @Test
    public void testCase2() {
        long result = expireAtMonth(0, 1, 0, 0);
        assertTrue(result > 0);
    }

    @Test
    public void testCase3() {
        long result = expireAtMonth(12, 31, 23, 59);
        assertTrue(result > 0);
    }

    @Test
    public void testCase4() {
        long result = expireAtMonth(1, 1, 0, 0);
        assertTrue(result > 0);
    }

    @Test
    public void testCase5() {
        long result = expireAtMonth(1, 31, 23, 59);
        assertTrue(result > 0);
    }

    @Test
    public void testCase6() {
        long result = expireAtMonth(0, 1, 23, 59);
        assertTrue(result > 0);
    }
}
