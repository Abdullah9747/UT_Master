import org.junit.Test;
import static org.junit.Assert.*;

public class IbMzqJkeJTest {

    @Test
    public void testIbMzqJkeJP_0() {
        IbMzqJkeJ obj = new IbMzqJkeJ();
        obj.IbMzqJkeJP(0);
    }

    @Test
    public void testIbMzqJkeJP_1() {
        IbMzqJkeJ obj = new IbMzqJkeJ();
        obj.IbMzqJkeJP(1);
    }

    @Test
    public void testIbMzqJkeJP_neg1() {
        IbMzqJkeJ obj = new IbMzqJkeJ();
        obj.IbMzqJkeJP(-1);
    }
}
