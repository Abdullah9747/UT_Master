import org.junit.Test;
import static org.junit.Assert.*;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.linear.ArrayRealVector;

public class MyClassTest {

    private static class MyClass {
        private RealVector vector;
        private int offset;

        public MyClass(RealVector vector, int offset) {
            this.vector = vector;
            this.offset = offset;
        }

        public double getQuick(int index) {
            return vector.getQuick(offset + index);
        }
    }

    @Test
    public void testGetQuick_ValidIndex() {
        double[] data = {1.0, 2.0, 3.0, 4.0, 5.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = 1;
        MyClass myObject = new MyClass(vector, offset);
        int index = 1;
        double result = myObject.getQuick(index);
        assertEquals(3.0, result, 1e-9);
    }

    @Test
    public void testGetQuick_IndexZero() {
        double[] data = {1.0, 2.0, 3.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = 0;
        MyClass myObject = new MyClass(vector, offset);
        int index = 0;
        double result = myObject.getQuick(index);
        assertEquals(1.0, result, 1e-9);
    }

    @Test
    public void testGetQuick_OffsetZero() {
        double[] data = {1.0, 2.0, 3.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = 0;
        MyClass myObject = new MyClass(vector, offset);
        int index = 2;
        double result = myObject.getQuick(index);
        assertEquals(3.0, result, 1e-9);
    }


    @Test
    public void testGetQuick_NearOutOfBounds_Positive() {
        double[] data = {1.0, 2.0, 3.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = 1;
        MyClass myObject = new MyClass(vector, offset);
        int index = 1;
        double result = myObject.getQuick(index);
        assertEquals(3.0, result, 1e-9);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetQuick_OutOfBounds_Positive() {
        double[] data = {1.0, 2.0, 3.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = 1;
        MyClass myObject = new MyClass(vector, offset);
        int index = 2;
        myObject.getQuick(index);
    }

    @Test
    public void testGetQuick_NearOutOfBounds_Negative() {
        double[] data = {1.0, 2.0, 3.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = -1;
        MyClass myObject = new MyClass(vector, offset);
        int index = 1;
        double result = myObject.getQuick(index);
        assertEquals(2.0, result, 1e-9);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetQuick_OutOfBounds_Negative() {
        double[] data = {1.0, 2.0, 3.0};
        RealVector vector = new ArrayRealVector(data);
        int offset = -2;
        MyClass myObject = new MyClass(vector, offset);
        int index = 0;
        myObject.getQuick(index);
    }
}
