import org.junit.Test;
import static org.junit.Assert.*;

public class QVZrbcSRshTest {

    @Test
    public void testQVZrbcSRsh_true() {
        assertEquals("The condition is true.", QVZrbcSRshWrapper.QVZrbcSRsh(true));
    }

    @Test
    public void testQVZrbcSRsh_false() {
        assertEquals("The condition is false.", QVZrbcSRshWrapper.QVZrbcSRsh(false));
    }

    static class QVZrbcSRshWrapper {
        static String QVZrbcSRsh(boolean upftBzhWLY) {
            if (upftBzhWLY) {
                return "The condition is true.";
            } else {
                return "The condition is false.";
            }
        }
    }
}
