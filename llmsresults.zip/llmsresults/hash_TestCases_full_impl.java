import com.google.common.primitives.Ints;
import org.junit.Test;
import java.nio.ByteBuffer;

import static org.junit.Assert.*;

public class SolutionTest {

    // Mock the underlying hash function.  Replace with actual call if available.
    private static int hash(ByteBuffer buffer, int seed) {
        // Replace this with a real implementation or mock.
        // This is just a placeholder to allow the tests to compile and run.
        // The actual hashing logic is not tested here.
        return seed + buffer.getInt(0); // Simple example
    }


    @Test
    public void testHash_basic() {
        assertEquals(0, SolutionTest.hash(ByteBuffer.wrap(Ints.toByteArray(0)), 0));
    }

    @Test
    public void testHash_positive() {
        assertEquals(67890 + 12345, SolutionTest.hash(ByteBuffer.wrap(Ints.toByteArray(12345)), 67890));
    }

    @Test
    public void testHash_negative() {
        assertEquals(67890 - 12345, SolutionTest.hash(ByteBuffer.wrap(Ints.toByteArray(-12345)), 67890));
    }

    @Test
    public void testHash_maxInt() {
        assertEquals(1 + Integer.MAX_VALUE, SolutionTest.hash(ByteBuffer.wrap(Ints.toByteArray(Integer.MAX_VALUE)), 1));
    }

    @Test
    public void testHash_minInt() {
        assertEquals(1 + Integer.MIN_VALUE, SolutionTest.hash(ByteBuffer.wrap(Ints.toByteArray(Integer.MIN_VALUE)), 1));
    }
}
