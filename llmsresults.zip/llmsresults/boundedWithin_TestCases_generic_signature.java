import org.junit.Test;
import static org.junit.Assert.*;

public class XXIsidmRUYTest {

    @Test
    public void testCase1_True() {
        assertTrue(xXIsidmRUY(1.0, 2.0, 3.0, 4.0));
    }

    @Test
    public void testCase2_False() {
        assertFalse(xXIsidmRUY(5.0, 6.0, 1.0, 2.0));
    }

    private boolean xXIsidmRUY(double iunhniUQiR, double hikZUeTkUC, double HsUObNIIyI, double VsfCKQdvne) {
        return (iunhniUQiR * hikZUeTkUC) < (HsUObNIIyI * VsfCKQdvne);
    }
}
