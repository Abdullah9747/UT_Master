import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class GetQuickTest {

    @Test
    public void testGetQuick_Zero() {
        GetQuick getQuickInstance = new GetQuick();
        assertEquals(0.0, getQuickInstance.getQuick(0), 0.0001);
    }

    @Test
    public void testGetQuick_One() {
        GetQuick getQuickInstance = new GetQuick();
        assertEquals(1.0, getQuickInstance.getQuick(1), 0.0001);
    }

    @Test
    public void testGetQuick_Three() {
        GetQuick getQuickInstance = new GetQuick();
        assertEquals(1.8333, getQuickInstance.getQuick(3), 0.0001);
    }
}
