import org.junit.Test;
import static org.junit.Assert.*;

public class HashFunctionTest {

    @Test
    public void testBasicCase() {
        assertEquals(32, hash(1, 1));
    }

    @Test
    public void testZeroValues() {
        assertEquals(0, hash(0, 0));
    }

    @Test
    public void testNegativeValues() {
        assertEquals(-32, hash(-1, -1));
    }

    @Test
    public void testLargeValues() {
        int rMIccwNlkS = Integer.MAX_VALUE / 31;
        int gBmXXDRAAn = 1;
        long expected = (long)31 * rMIccwNlkS + gBmXXDRAAn;
        if (expected > Integer.MAX_VALUE || expected < Integer.MIN_VALUE) {
            int expectedInt = (int) expected;
            assertEquals(expectedInt, hash(rMIccwNlkS, gBmXXDRAAn));
        } else {
            assertEquals((int)expected, hash(rMIccwNlkS, gBmXXDRAAn));
        }
    }

    int hash(int rMIccwNlkS, int gBmXXDRAAn) {
        int h = 31 * rMIccwNlkS + gBmXXDRAAn;
        return h;
    }
}
