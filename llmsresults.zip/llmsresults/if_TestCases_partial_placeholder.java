import org.junit.Test;
import static org.junit.Assert.*;

public class MyTest {

    @Test
    public void testNullEqualsNull() {
        Object raf = null;
        Object XWxgufCiHz = null;
        assertTrue(raf == XWxgufCiHz);
    }

    @Test
    public void testSameObject() {
        Object obj = new Object();
        Object raf = obj;
        Object XWxgufCiHz = obj;
        assertTrue(raf == XWxgufCiHz);
    }

    @Test
    public void testNullNotEqualsObject() {
        Object raf = null;
        Object XWxgufCiHz = new Object();
        assertFalse(raf == XWxgufCiHz);
    }

    @Test
    public void testObjectNotEqualsNull() {
        Object raf = new Object();
        Object XWxgufCiHz = null;
        assertFalse(raf == XWxgufCiHz);
    }

    @Test
    public void testDifferentObjects() {
        Object raf = new Object();
        Object XWxgufCiHz = new Object();
        assertFalse(raf == XWxgufCiHz);
    }

    @Test
    public void testIntegerEqualsInteger(){
        Integer raf = 5;
        Integer XWxgufCiHz = 5;
        assertTrue(raf.intValue() == XWxgufCiHz.intValue()); // comparing values, not references for Integer objects.

    }
    @Test
    public void testIntegerNotEqualsInteger(){
        Integer raf = 5;
        Integer XWxgufCiHz = 6;
        assertFalse(raf.intValue() == XWxgufCiHz.intValue()); // comparing values, not references for Integer objects.

    }

    @Test
    public void testIntegerEqualsIntegerObject(){
        Integer raf = new Integer(5);
        Integer XWxgufCiHz = new Integer(5);
        assertFalse(raf == XWxgufCiHz); // different objects, same value
    }

    @Test
    public void testIntegerNotEqualsIntegerObject(){
        Integer raf = new Integer(5);
        Integer XWxgufCiHz = new Integer(6);
        assertFalse(raf == XWxgufCiHz); // different objects, different value
    }
}
