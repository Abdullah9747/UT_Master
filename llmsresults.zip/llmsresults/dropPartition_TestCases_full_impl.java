import org.junit.Test;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

class PartitionManager { // Assuming this class contains dropPartition

    private Map<Integer, Long> latestPartitionsOffset = new HashMap<>();
    private Map<Integer, Long> latestHeartbeats = new HashMap<>();

    public void dropPartition(int partition) {
        latestPartitionsOffset.remove(partition);
        latestHeartbeats.remove(partition);
    }

    // Getter for the Maps to assert their state after the dropPartition call.
    public Map<Integer, Long> getLatestPartitionsOffset() {
        return latestPartitionsOffset;
    }

    public Map<Integer, Long> getLatestHeartbeats() {
        return latestHeartbeats;
    }
}


public class PartitionManagerTest {

    @Test
    public void testDropPartition() {
        // Arrange (Set up the test environment)
        PartitionManager partitionManager = new PartitionManager();

        // Add the partition to both maps before calling dropPartition
        int partitionId = 123;
        partitionManager.getLatestPartitionsOffset().put(partitionId, 456L); // Some offset value
        partitionManager.getLatestHeartbeats().put(partitionId, System.currentTimeMillis()); // Some heartbeat timestamp

        // Assert that the partition exists before dropping.
        assertTrue(partitionManager.getLatestPartitionsOffset().containsKey(partitionId));
        assertTrue(partitionManager.getLatestHeartbeats().containsKey(partitionId));

        // Act (Execute the code under test)
        partitionManager.dropPartition(partitionId);

        // Assert (Verify the results)
        assertFalse(partitionManager.getLatestPartitionsOffset().containsKey(partitionId));
        assertFalse(partitionManager.getLatestHeartbeats().containsKey(partitionId));
    }
}
