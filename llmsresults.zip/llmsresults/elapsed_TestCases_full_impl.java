import org.junit.Test;
import static org.junit.Assert.*;

public class ElapsedTest {

    @Test
    public void testElapsed1() {
        assertEquals(100L, Elapsed.elapsed(0L, 100L));
    }

    @Test
    public void testElapsed2() {
        // Behavior with finished < started is implementation-dependent.
        // Adjust assertion based on Times.elapsed's actual behavior.
        assertTrue(Elapsed.elapsed(100L, 0L) <= 0); // Expect negative or zero
    }

    @Test
    public void testElapsed3() {
        assertEquals(0L, Elapsed.elapsed(100L, 100L));
    }

    @Test
    public void testElapsed4() {
        assertEquals(100L, Elapsed.elapsed(Long.MAX_VALUE - 100L, Long.MAX_VALUE));
    }

    @Test
    public void testElapsed5() {
        assertEquals(100L, Elapsed.elapsed(Long.MIN_VALUE, Long.MIN_VALUE + 100L));
    }

   @Test
    public void testElapsed6() {
        // This test might fail with overflow. Expected a large positive value.
        assertTrue(Elapsed.elapsed(Long.MIN_VALUE, Long.MAX_VALUE) > 0);
    }

    @Test
    public void testElapsed7() {
        assertEquals(200L, Elapsed.elapsed(-100L, 100L));
    }
}
