import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class SolutionTest {

    @Test
    public void testToHexWithZeros_0() {
        assertEquals("00", Solution.toHexWithZeros((byte) 0));
    }

    @Test
    public void testToHexWithZeros_10() {
        assertEquals("0A", Solution.toHexWithZeros((byte) 10));
    }

    @Test
    public void testToHexWithZeros_127() {
        assertEquals("7F", Solution.toHexWithZeros((byte) 127));
    }

    @Test
    public void testToHexWithZeros_minus1() {
        assertEquals("FF", Solution.toHexWithZeros((byte) -1));
    }

    @Test
    public void testToHexWithZeros_minus128() {
        assertEquals("80", Solution.toHexWithZeros((byte) -128));
    }
}
