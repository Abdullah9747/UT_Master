import org.junit.Test;
import static org.junit.Assert.*;

public class DropPartitionTest {

    @Test
    public void testDropPartition_zero() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(0);
    }

    @Test
    public void testDropPartition_one() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(1);
    }

    @Test
    public void testDropPartition_minusOne() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(-1);
    }

    @Test
    public void testDropPartition_hundred() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(100);
    }

    @Test
    public void testDropPartition_minusHundred() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(-100);
    }

    @Test
    public void testDropPartition_maxValue() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(Integer.MAX_VALUE);
    }

    @Test
    public void testDropPartition_minValue() {
        DropPartition dropPartitionTest = new DropPartition();
        dropPartitionTest.dropPartition(Integer.MIN_VALUE);
    }
}
