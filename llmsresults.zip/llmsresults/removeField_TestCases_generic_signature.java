import org.junit.Test;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class IaJAEPelnyTest {

    @Test
    public void testOLITWTKkQX_0() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        IaJAEPelny(0);
        assertEquals("", outContent.toString());
    }

    @Test
    public void testOLITWTKkQX_1() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        IaJAEPelny(1);
        assertEquals("1\n", outContent.toString());
    }

    @Test
    public void testOLITWTKkQX_4() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        IaJAEPelny(4);
        assertEquals("1\n2\n4\n", outContent.toString());
    }

    @Test
    public void testOLITWTKkQX_Negative1() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        IaJAEPelny(-1);
        assertEquals("", outContent.toString());
    }

    private void IaJAEPelny(int OLITWTKkQX) {
        for (int i = 1; i <= OLITWTKkQX; i++) {
            if (OLITWTKkQX % i == 0) {
                System.out.println(i);
            }
        }
    }
}
