import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.Types;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class GetPreferredJavaTypeTest {

    @Test
    public void testBasicIntegerType() {
        assertEquals("java.lang.Integer", getPreferredJavaType(Types.INTEGER, 10, 0));
    }

    @Test
    public void testLargeIntegerType() {
        assertEquals("java.lang.Long", getPreferredJavaType(Types.INTEGER, 20, 0));
    }

    @Test
    public void testVarcharTypeShort() {
        assertEquals("java.lang.String", getPreferredJavaType(Types.VARCHAR, 50, 0));
    }

    @Test
    public void testVarcharTypeLong() {
        assertEquals("java.lang.String", getPreferredJavaType(Types.VARCHAR, 2000, 0));
    }

    @Test
    public void testDecimalTypeSmallPrecision() {
        assertEquals("java.math.BigDecimal", getPreferredJavaType(Types.DECIMAL, 5, 2));
    }

    @Test
    public void testNumericTypeLargePrecision() {
        assertEquals("java.math.BigDecimal", getPreferredJavaType(Types.NUMERIC, 20, 10));
    }

    @Test
    public void testDateType() {
        assertEquals("java.sql.Date", getPreferredJavaType(Types.DATE, 0, 0));
    }

    @Test
    public void testTimestampType() {
        assertEquals("java.sql.Timestamp", getPreferredJavaType(Types.TIMESTAMP, 0, 0));
    }

    @Test
    public void testBooleanType() {
        assertEquals("java.lang.Boolean", getPreferredJavaType(Types.BOOLEAN, 0, 0));
    }

    @Test
    public void testDoubleType() {
        assertEquals("java.lang.Double", getPreferredJavaType(Types.DOUBLE, 0, 0));
    }

    @Test
    public void testBlobType() {
        assertEquals("byte[]", getPreferredJavaType(Types.BLOB, 0, 0));
    }

    @Test
    public void testNullType() {
        assertEquals("java.lang.Object", getPreferredJavaType(Types.NULL, 0, 0));
    }

    @Test
    public void testUnknownType() {
        assertEquals("java.lang.Object", getPreferredJavaType(-999, 0, 0));
    }

    private String getPreferredJavaType(int sqlType, int size, int decimalDigits) {
        if (sqlType == Types.INTEGER) {
            if (size > 10) {
                return "java.lang.Long";
            } else {
                return "java.lang.Integer";
            }
        } else if (sqlType == Types.VARCHAR) {
            return "java.lang.String";
        } else if (sqlType == Types.DECIMAL || sqlType == Types.NUMERIC) {
            return "java.math.BigDecimal";
        } else if (sqlType == Types.DATE) {
            return "java.sql.Date";
        } else if (sqlType == Types.TIMESTAMP) {
            return "java.sql.Timestamp";
        } else if (sqlType == Types.BOOLEAN) {
            return "java.lang.Boolean";
        } else if (sqlType == Types.DOUBLE || sqlType == Types.FLOAT || sqlType == Types.REAL) {
            return "java.lang.Double";
        } else if (sqlType == Types.BLOB || sqlType == Types.BINARY) {
            return "byte[]";
        } else if (sqlType == Types.NULL) {
            return "java.lang.Object";
        } else {
            return "java.lang.Object";
        }
    }
}
