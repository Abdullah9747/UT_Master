import org.junit.Test;
import static org.junit.Assert.*;

public class ColumnTest {

    @Test
    public void testSetColspan() {
        Column column = new Column();
        Column returnedColumn = column.setColspan(5);

        assertEquals(5, column.getColspan());
        assertSame(column, returnedColumn);
    }
}
