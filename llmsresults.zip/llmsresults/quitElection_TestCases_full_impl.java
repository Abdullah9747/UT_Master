import org.junit.Test;
import org.junit.Before;
import org.mockito.Mockito;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class QuitElectionTest {

    private MyClass myObject;

    @Before
    public void setUp() {
        myObject = Mockito.spy(new MyClass());
    }

    @Test
    public void testQuitElection_NeedFenceFalse_StateActive() {
        myObject.needFence = false;
        myObject.state = State.ACTIVE;
        myObject.wantToBeInElection = true;

        myObject.quitElection(myObject.needFence);

        verify(myObject, times(1)).tryDeleteOwnBreadCrumbNode();
        verify(myObject, times(1)).reset();
        assertFalse(myObject.wantToBeInElection);
    }

    @Test
    public void testQuitElection_NeedFenceTrue_StateActive() {
        myObject.needFence = true;
        myObject.state = State.ACTIVE;
        myObject.wantToBeInElection = true;

        myObject.quitElection(myObject.needFence);

        verify(myObject, never()).tryDeleteOwnBreadCrumbNode();
        verify(myObject, times(1)).reset();
        assertFalse(myObject.wantToBeInElection);
    }

    @Test
    public void testQuitElection_NeedFenceFalse_StateStandby() {
        myObject.needFence = false;
        myObject.state = State.STANDBY;
        myObject.wantToBeInElection = true;

        myObject.quitElection(myObject.needFence);

        verify(myObject, never()).tryDeleteOwnBreadCrumbNode();
        verify(myObject, times(1)).reset();
        assertFalse(myObject.wantToBeInElection);
    }

    enum State {
        ACTIVE,
        STANDBY,
        INACTIVE
    }

    class MyClass {
        public boolean needFence;
        public State state;
        public boolean wantToBeInElection;

        public void quitElection(boolean needFence) {
            System.out.println("Yielding from election");
            if (!needFence && state == State.ACTIVE) {
                tryDeleteOwnBreadCrumbNode();
            }
            reset();
            wantToBeInElection = false;
        }

        public void tryDeleteOwnBreadCrumbNode() {
            System.out.println("Deleting breadcrumb");
        }

        public void reset() {
            System.out.println("Resetting");
        }
    }
}
