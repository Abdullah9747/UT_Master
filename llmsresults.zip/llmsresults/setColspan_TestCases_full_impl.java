import org.junit.Test;
import static org.junit.Assert.*;

public class ColumnTest {

    @Test
    public void setColspan_validColspan() {
        Column column = new Column();
        Column returnedColumn = column.setColspan(5);
        assertEquals(5, column.getColspan()); // Assuming getColspan() exists
        assertEquals(column, returnedColumn); // Check for method chaining
    }

    @Test(expected = IllegalArgumentException.class)
    public void setColspan_invalidColspanTooSmall() {
        Column column = new Column();
        column.setColspan(0);
        //Alternatively, if checkColspan modifies the value:
        //column.setColspan(0);
        //assertEquals(1, column.getColspan());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setColspan_invalidColspanTooLarge() {
        Column column = new Column();
        column.setColspan(11);
        //Alternatively, if checkColspan modifies the value:
        //column.setColspan(11);
        //assertEquals(10, column.getColspan());
    }

    @Test
    public void setColspan_minimumValidColspan() {
        Column column = new Column();
        Column returnedColumn = column.setColspan(1);
        assertEquals(1, column.getColspan());
        assertEquals(column, returnedColumn); // Check for method chaining
    }

     @Test
    public void setColspan_maximumValidColspan() {
        Column column = new Column();
        Column returnedColumn = column.setColspan(10);
        assertEquals(10, column.getColspan());
        assertEquals(column, returnedColumn); // Check for method chaining
    }

    // Mock Column Class for testing purposes
    private static class Column {
        private int colspan;

        public Column setColspan(int colspan) {
            this.colspan = checkColspan(colspan);
            return this;
        }

        public int getColspan() {
            return colspan;
        }

        private int checkColspan(int colspan) {
            if (colspan < 1) {
                throw new IllegalArgumentException("Colspan must be at least 1");
            }
            if (colspan > 10) {
                 throw new IllegalArgumentException("Colspan cannot be greater than 10");
            }
            return colspan;
        }
    }
}
