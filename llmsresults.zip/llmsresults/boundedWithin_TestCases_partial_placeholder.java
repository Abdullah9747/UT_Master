import org.junit.Test;
import static org.junit.Assert.*;

public class BoundedWithinTest {

    @Test
    public void testCase1() {
        assertTrue(boundedWithin(5.0, 2.0, 8.0, 0));
    }

    @Test
    public void testCase2() {
        assertFalse(boundedWithin(1.0, 2.0, 8.0, 0));
    }

    @Test
    public void testCase3() {
        assertFalse(boundedWithin(9.0, 2.0, 8.0, 0));
    }

    @Test
    public void testCase4() {
        assertTrue(boundedWithin(5.0, 2.0, 8.0, 1));
    }

    @Test
    public void testCase5() {
        assertFalse(boundedWithin(1.0, 2.0, 8.0, 1));
    }

    @Test
    public void testCase6() {
        assertFalse(boundedWithin(9.0, 2.0, 8.0, 1));
    }

    @Test
    public void testCase7() {
        assertTrue(boundedWithin(2.0, 2.0, 8.0, 1));
    }

    @Test
    public void testCase8() {
        assertTrue(boundedWithin(8.0, 2.0, 8.0, 1));
    }

    @Test
    public void testCase9() {
        assertTrue(boundedWithin(5.0, 2.0, 8.0, -1));
    }

    @Test
    public void testCase10() {
        assertTrue(boundedWithin(5.0, 2.0, 8.0, 2.5));
    }

    @Test
    public void testCase11() {
        assertFalse(boundedWithin(2.0, 2.0, 8.0, 0));
    }

    @Test
    public void testCase12() {
        assertFalse(boundedWithin(8.0, 2.0, 8.0, 0));
    }

    @Test
    public void testCase13() {
        assertTrue(boundedWithin(2.00000000000001, 2.0, 8.0, 0));
    }

    @Test
    public void testCase14() {
        assertTrue(boundedWithin(7.99999999999999, 2.0, 8.0, 0));
    }

    @Test
    public void testCase15() {
        assertTrue(boundedWithin(2.00000000000001, 2.0, 8.0, 1));
    }

    @Test
    public void testCase16() {
        assertTrue(boundedWithin(7.99999999999999, 2.0, 8.0, 1));
    }

    private boolean boundedWithin(double kLmjJEoHOk, double zlnblnKoBx, double wRxCZYsYix, double xGhYRStQYG) {
        if (xGhYRStQYG == 0) {
            return kLmjJEoHOk > zlnblnKoBx && kLmjJEoHOk < wRxCZYsYix;
        } else {
            return kLmjJEoHOk >= zlnblnKoBx && kLmjJEoHOk <= wRxCZYsYix;
        }
    }
}
