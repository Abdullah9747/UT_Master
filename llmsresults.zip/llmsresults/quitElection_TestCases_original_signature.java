mport org.junit.Test;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class QuitElectionTest {

    @Test
    public void testQuitElection_needFenceTrue() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        QuitElectionClass.quitElection(true);

        String expectedOutput = "I'm quitting the election!\n" +
                "Building a fence around myself for protection...\n" +
                "Fence built!  I'm now safe from tomatoes and bad press.\n" +
                "Good luck to the remaining candidates!\n";

        assertEquals(expectedOutput, outContent.toString());

        System.setOut(originalOut);
    }

    @Test
    public void testQuitElection_needFenceFalse() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        QuitElectionClass.quitElection(false);

        String expectedOutput = "I'm quitting the election!\n" +
                "I'm leaving quietly, without a fence.\n" +
                "Good luck to the remaining candidates!\n";

        assertEquals(expectedOutput, outContent.toString());

        System.setOut(originalOut);
    }

    static class QuitElectionClass {
        static void quitElection(boolean needFence) {
            System.out.println("I'm quitting the election!");
            if (needFence) {
                System.out.println("Building a fence around myself for protection...");
                System.out.println("Fence built!  I'm now safe from tomatoes and bad press.");
            } else {
                System.out.println("I'm leaving quietly, without a fence.");
            }
            System.out.println("Good luck to the remaining candidates!");
        }
    }
}
