import org.junit.Test;
import static org.junit.Assert.*;

public class PartitionManagerTest {

    class PartitionManager {  // Inner class for testing purposes.  Would be a separate class in a real project.
        int numberOfPartitions;
        Object[] data; // Using Object[] for simplicity

        public PartitionManager(int numPartitions) {
            numberOfPartitions = numPartitions;
            data = new Object[numPartitions];
            for (int i = 0; i < numPartitions; i++) {
                data[i] = new Object(); // Initialize with some dummy data
            }
        }

        void dropPartition(int partition) {
            if (partition >= 0 && partition < numberOfPartitions) {
                data[partition] = null;
                System.out.println("Partition " + partition + " dropped.");
            } else {
                System.out.println("Invalid partition number: " + partition);
            }
        }

        public Object getData(int index) {
            return data[index];
        }
    }

    @Test
    public void testValidPartition() {
        PartitionManager pm = new PartitionManager(3);
        pm.dropPartition(1);
        assertNull(pm.getData(1));
    }

    @Test
    public void testInvalidPartitionNegative() {
        PartitionManager pm = new PartitionManager(3);
        Object originalData = pm.getData(0); // Store original data for comparison
        pm.dropPartition(-1);
        assertNotNull(originalData); // Verify that existing data remains untouched
        assertEquals(originalData, pm.getData(0));  // More precise check that data hasn't changed
    }

    @Test
    public void testInvalidPartitionTooHigh() {
        PartitionManager pm = new PartitionManager(3);
        Object originalData = pm.getData(0); // Store original data for comparison
        pm.dropPartition(3);
        assertNotNull(originalData); // Verify that existing data remains untouched
        assertEquals(originalData, pm.getData(0));  // More precise check that data hasn't changed

    }

    @Test
    public void testValidPartitionBoundaryFirst() {
        PartitionManager pm = new PartitionManager(3);
        pm.dropPartition(0);
        assertNull(pm.getData(0));
    }

    @Test
    public void testValidPartitionBoundaryLast() {
        PartitionManager pm = new PartitionManager(3);
        pm.dropPartition(2);
        assertNull(pm.getData(2));
    }
}
