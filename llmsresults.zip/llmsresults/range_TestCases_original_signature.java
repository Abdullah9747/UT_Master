import org.junit.Test;
import static org.junit.Assert.*;
import java.util.regex.Pattern;

public class SolutionTest {

    @Test
    public void testInvalidRange() {
        Solution sol = new Solution();
        Pattern result = sol.range('b', 'a');
        assertNull(result, "Should return null for invalid range (b > a)");
    }

    @Test
    public void testValidRange() {
        Solution sol = new Solution();
        Pattern result = sol.range('a', 'z');
        assertNotNull(result, "Should return a Pattern for valid range (a < z)");
        assertTrue(result.matcher("b").matches(), "Pattern should match 'b'");
        assertFalse(result.matcher("1").matches(), "Pattern should not match '1'");
    }

    @Test
    public void testEqualRange() {
        Solution sol = new Solution();
        Pattern result = sol.range('a', 'a');
        assertNotNull(result, "Should return a Pattern for equal range (a == a)");
        assertTrue(result.matcher("a").matches(), "Pattern should match 'a'");
        assertFalse(result.matcher("b").matches(), "Pattern should not match 'b'");
    }
}
