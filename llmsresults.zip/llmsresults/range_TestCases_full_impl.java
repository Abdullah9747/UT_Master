import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.regex.Pattern;

import static org.junit.Assert.*;

@RunWith(JUnit4.class)
public class SolutionTest {

    @Test
    public void testRange_a_c() {
        Pattern pattern = Solution.range('a', 'c');
        assertNotNull(pattern);
        assertTrue(pattern.matcher("a").matches());
        assertTrue(pattern.matcher("b").matches());
        assertTrue(pattern.matcher("c").matches());
        assertFalse(pattern.matcher("d").matches());
    }

    @Test
    public void testRange_z_a() {
        Pattern pattern = Solution.range('z', 'a');
        assertNotNull(pattern);
        // Assuming it returns a pattern that matches nothing, or throws an exception.
        assertFalse(pattern.matcher("a").matches());
        assertFalse(pattern.matcher("z").matches());
    }

    @Test
    public void testRange_0_9() {
        Pattern pattern = Solution.range('0', '9');
        assertNotNull(pattern);
        assertTrue(pattern.matcher("0").matches());
        assertTrue(pattern.matcher("5").matches());
        assertTrue(pattern.matcher("9").matches());
        assertFalse(pattern.matcher("a").matches());
    }

    @Test
    public void testRange_A_Z() {
        Pattern pattern = Solution.range('A', 'Z');
        assertNotNull(pattern);
        assertTrue(pattern.matcher("A").matches());
        assertTrue(pattern.matcher("M").matches());
        assertTrue(pattern.matcher("Z").matches());
        assertFalse(pattern.matcher("a").matches());
    }

    @Test
    public void testRange_space_exclamation() {
        Pattern pattern = Solution.range(' ', '!');
        assertNotNull(pattern);
        assertTrue(pattern.matcher(" ").matches());
        assertTrue(pattern.matcher("!").matches());
        assertFalse(pattern.matcher("a").matches());
    }

    @Test
    public void testRange_a_a() {
        Pattern pattern = Solution.range('a', 'a');
        assertNotNull(pattern);
        assertTrue(pattern.matcher("a").matches());
        assertFalse(pattern.matcher("b").matches());
    }

    @Test
    public void testRange_ascii_0_127() {
        Pattern pattern = Solution.range((char)0, (char)127);
        assertNotNull(pattern);
        assertTrue(pattern.matcher("A").matches());
        assertTrue(pattern.matcher("0").matches());
        assertTrue(pattern.matcher(" ").matches());
        assertTrue(pattern.matcher("\u007F").matches());
    }
}
