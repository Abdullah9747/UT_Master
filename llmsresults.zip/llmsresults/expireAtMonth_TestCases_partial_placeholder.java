import org.junit.Test;
import static org.junit.Assert.*;

import java.time.*;
import java.time.temporal.TemporalAdjusters;

public class ExpirationDateCalculatorTest {

    @Test
    public void testBasicCase() {
        int year = 2024;
        int month = 10;
        int day = 15;
        int duration = 3;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testZeroDuration() {
        int year = 2024;
        int month = 10;
        int day = 15;
        int duration = 0;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testOneMonthDuration() {
        int year = 2024;
        int month = 10;
        int day = 15;
        int duration = 1;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testEndOfYearRollover() {
        int year = 2024;
        int month = 12;
        int day = 15;
        int duration = 2;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testMultipleYearRollover() {
        int year = 2024;
        int month = 11;
        int day = 15;
        int duration = 14;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testLeapYearStartInFebruary() {
        int year = 2024;
        int month = 2;
        int day = 15;
        int duration = 1;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testLeapYearEndInFebruary() {
        int year = 2024;
        int month = 1;
        int day = 15;
        int duration = 1;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testLargeDuration() {
        int year = 2024;
        int month = 1;
        int day = 15;
        int duration = 120;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testNearIntegerMaxValueDuration() {
        int year = 2024;
        int month = 1;
        int day = 15;
        int duration = 2147483647;
        try {
            LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
            LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

            LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

            assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
            assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
            assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
        } catch (DateTimeException e){
            assertTrue(true); // expecting an exception
            return;
        } catch (ArithmeticException e){
            assertTrue(true); // expecting an exception
            return;
        }
    }

    @Test
    public void testStartAtTheEndOfMonth() {
        int year = 2024;
        int month = 10;
        int day = 31;
        int duration = 3;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testStartInJanuaryDuration12() {
        int year = 2024;
        int month = 1;
        int day = 15;
        int duration = 12;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testStartInFebruaryNonLeap() {
        int year = 2023;
        int month = 2;
        int day = 28;
        int duration = 1;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testNegativeDuration() {
        int year = 2024;
        int month = 10;
        int day = 15;
        int duration = -1;
        try {
            expireAtMonth(year, month, day, duration);
            fail("Expected an IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertTrue(true);
        } catch (DateTimeException e) {
            assertTrue(true);
        }
    }

    @Test
    public void testYear0() {
        int year = 0;
        int month = 1;
        int day = 15;
        int duration = 12;

        LocalDateTime startDate = LocalDateTime.of(1, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }

    @Test
    public void testLargeYearValue() {
        int year = 9999;
        int month = 1;
        int day = 15;
        int duration = 12;

        LocalDateTime startDate = LocalDateTime.of(year, month, day, 0, 0);
        LocalDateTime expectedExpiration = startDate.plusMonths(duration).with(TemporalAdjusters.lastDayOfMonth()).withHour(23).withMinute(59).withSecond(59);

        LocalDateTime actualExpiration = Instant.ofEpochMilli(expireAtMonth(year, month, day, duration)).atZone(ZoneOffset.UTC).toLocalDateTime();

        assertEquals(expectedExpiration.getYear(), actualExpiration.getYear());
        assertEquals(expectedExpiration.getMonth(), actualExpiration.getMonth());
        assertEquals(expectedExpiration.getDayOfMonth(), actualExpiration.getDayOfMonth());
    }
    private long expireAtMonth(int NnYWWWLavi, int xDjdwMeJup, int vniFeKDRxr, int uBpDjnvOzg){
        YearMonth ym = YearMonth.of(NnYWWWLavi, xDjdwMeJup).plusMonths(uBpDjnvOzg);
        LocalDate ld = ym.atEndOfMonth();
        LocalDateTime ldt = ld.atTime(23, 59, 59);
        ZonedDateTime zdt = ldt.atZone(ZoneOffset.UTC);
        return zdt.toInstant().toEpochMilli();
    }
}
