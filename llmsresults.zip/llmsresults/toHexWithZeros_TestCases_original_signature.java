mport org.junit.Test;
import static org.junit.Assert.*;

public class ToHexWithZerosTest {

    @Test
    public void testToHexWithZeros_leadingZeroNeeded() {
        assertEquals("0a", toHexWithZeros((byte) 10));
    }

    @Test
    public void testToHexWithZeros_noLeadingZeroNeeded() {
        assertEquals("ff", toHexWithZeros((byte) 255));
    }

    @Test
    public void testToHexWithZeros_zeroValue() {
        assertEquals("00", toHexWithZeros((byte) 0));
    }

    @Test
    public void testToHexWithZeros_noLeadingZeroNeeded_2() {
        assertEquals("10", toHexWithZeros((byte) 16));
    }

    String toHexWithZeros(byte b) {
        int unsignedByte = b & 0xFF;
        String hexString = Integer.toHexString(unsignedByte);
        if (hexString.length() == 1) {
            return "0" + hexString;
        } else {
            return hexString;
        }
    }
}
