import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class RemoveFieldTest {

    private MyClass myObject;
    private final int NULL_INDICATOR_OFFSET = -1; // Example value, adjust as needed

    class MyClass {
        public int numFields;
        public int[] offsets;
        public int[] lengths;
        public Object[] readFields;
        public Object[] writeFields;

        public MyClass(int size) {
            numFields = 0; // Initialize to 0
            offsets = new int[size];
            lengths = new int[size];
            readFields = new Object[size];
            writeFields = new Object[size];
        }


        public void removeField(int fieldNum) {
            // range check
            if (fieldNum < 0 || fieldNum >= this.numFields) {
                throw new IndexOutOfBoundsException();
            }
            int lastIndex = this.numFields - 1;

            if (fieldNum < lastIndex) {
                int len = lastIndex - fieldNum;
                System.arraycopy(this.offsets, fieldNum + 1, this.offsets, fieldNum, len);
                System.arraycopy(this.lengths, fieldNum + 1, this.lengths, fieldNum, len);
                System.arraycopy(this.readFields, fieldNum + 1, this.readFields, fieldNum, len);
                System.arraycopy(this.writeFields, fieldNum + 1, this.writeFields, fieldNum, len);
                markModified(fieldNum);
            }
            this.offsets[lastIndex] = NULL_INDICATOR_OFFSET;
            this.lengths[lastIndex] = 0;
            this.writeFields[lastIndex] = null;

            setNumFields(lastIndex);
        }

        public void setNumFields(int numFields) {
            this.numFields = numFields;
        }

        public void markModified(int fieldNum) {
            // Dummy implementation for testing purposes
        }

    }

    @Before
    public void setUp() {
        myObject = new MyClass(3); // Initialize with a size
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testRemoveField_TC1_EmptyList() {
        myObject.numFields = 0;
        myObject.removeField(0);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testRemoveField_TC2_IndexTooLow() {
        myObject.numFields = 1;
        myObject.removeField(-1);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testRemoveField_TC3_IndexTooHigh() {
        myObject.numFields = 1;
        myObject.removeField(1);
    }


    @Test
    public void testRemoveField_TC4_SingleElement() {
        myObject.numFields = 1;
        myObject.offsets[0] = 10;
        myObject.lengths[0] = 20;
        myObject.readFields[0] = new Object();
        myObject.writeFields[0] = new Object();

        myObject.removeField(0);

        assertEquals(0, myObject.numFields);
        assertEquals(NULL_INDICATOR_OFFSET, myObject.offsets[0]);
        assertEquals(0, myObject.lengths[0]);
        assertNull(myObject.writeFields[0]);
    }


    @Test
    public void testRemoveField_TC5_MiddleElement() {
        myObject.numFields = 3;
        myObject.offsets[0] = 10;
        myObject.offsets[1] = 20;
        myObject.offsets[2] = 30;
        myObject.lengths[0] = 40;
        myObject.lengths[1] = 50;
        myObject.lengths[2] = 60;
        myObject.readFields[0] = new Object();
        myObject.readFields[1] = new Object();
        myObject.readFields[2] = new Object();
        myObject.writeFields[0] = new Object();
        myObject.writeFields[1] = new Object();
        myObject.writeFields[2] = new Object();

        MyClass spy = Mockito.spy(myObject);

        spy.removeField(1);

        assertEquals(2, spy.numFields);
        assertEquals(10, spy.offsets[0]);
        assertEquals(30, spy.offsets[1]);
        assertEquals(40, spy.lengths[0]);
        assertEquals(60, spy.lengths[1]);
        assertNotNull(spy.readFields[0]);
        assertNotNull(spy.readFields[1]);
        assertNotNull(spy.writeFields[0]);
        assertNull(spy.writeFields[1]);
        assertEquals(NULL_INDICATOR_OFFSET, spy.offsets[2]);
        assertEquals(0, spy.lengths[2]);
        assertNull(spy.writeFields[2]);

    }

    @Test
    public void testRemoveField_TC6_LastElement() {
        myObject.numFields = 3;
        myObject.offsets[0] = 10;
        myObject.offsets[1] = 20;
        myObject.offsets[2] = 30;
        myObject.lengths[0] = 40;
        myObject.lengths[1] = 50;
        myObject.lengths[2] = 60;
        myObject.readFields[0] = new Object();
        myObject.readFields[1] = new Object();
        myObject.readFields[2] = new Object();
        myObject.writeFields[0] = new Object();
        myObject.writeFields[1] = new Object();
        myObject.writeFields[2] = new Object();

        myObject.removeField(2);

        assertEquals(2, myObject.numFields);
        assertEquals(10, myObject.offsets[0]);
        assertEquals(20, myObject.offsets[1]);
        assertEquals(40, myObject.lengths[0]);
        assertEquals(50, myObject.lengths[1]);
        assertNotNull(myObject.readFields[0]);
        assertNotNull(myObject.readFields[1]);
        assertNotNull(myObject.writeFields[0]);
        assertNotNull(myObject.writeFields[1]);
        assertEquals(NULL_INDICATOR_OFFSET, myObject.offsets[2]);
        assertEquals(0, myObject.lengths[2]);
        assertNull(myObject.writeFields[2]);
    }
}
