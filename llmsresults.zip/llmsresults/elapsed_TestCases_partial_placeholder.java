import org.junit.Test;
import static org.junit.Assert.*;

public class ElapsedTest {

    @Test
    public void testPositiveDifference() {
        assertEquals(500, elapsed(1000, 500));
    }

    @Test
    public void testZeroDifference() {
        assertEquals(0, elapsed(750, 750));
    }

    @Test
    public void testNegativeDifference() {
        assertEquals(-200, elapsed(200, 400));
    }

    @Test
    public void testLargePositiveNumbers() {
        assertEquals(Long.MAX_VALUE - 1, elapsed(Long.MAX_VALUE, 1));
    }

    @Test
    public void testLargeNegativeNumbers() {
        assertEquals(-1 - Long.MIN_VALUE, elapsed(-1, Long.MIN_VALUE));
    }

    @Test
    public void testSecondValueIsZero() {
        assertEquals(100, elapsed(100, 0));
    }

    private long elapsed(long GFzsfBQzIY, long VSaCgDSVvx) {
        return GFzsfBQzIY - VSaCgDSVvx;
    }
}
