import org.junit.Test;
import static org.junit.Assert.*;

public class ColumnTest {

    @Test
    public void testIAJjgejINI() {
        int input = 0;
        Column result = new Column();
        result.setColumnIndex(input);

        Column actual = iAJjgejINI(input);

        assertEquals(result.getColumnIndex(), actual.getColumnIndex());
    }

    static class Column {
        private int columnIndex;

        public Column() {}

        public int getColumnIndex() {
            return columnIndex;
        }

        public void setColumnIndex(int columnIndex) {
            this.columnIndex = columnIndex;
        }
    }

    Column iAJjgejINI(int uAPfBrXcJJ) {
        Column localColumn = new Column();
        localColumn.setColumnIndex(uAPfBrXcJJ);
        return localColumn;
    }
}
