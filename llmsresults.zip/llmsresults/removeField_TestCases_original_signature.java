import org.junit.Test;
import static org.junit.Assert.*;

public class RemoveFieldTest {

    private int numFields = 3;
    private Object[] fields = new Object[]{"A", "B", "C"};
    private boolean errorPrinted = false;

    private int getNumFields() {
        return numFields;
    }

    private Object getField(int index) {
        return fields[index];
    }

    private void setField(int index, Object field) {
        fields[index] = field;
    }

    private void removeLastField() {
        if (numFields > 0) {
            fields[numFields - 1] = null;
            numFields--;
        }
    }

    private void resetFields(){
        numFields = 3;
        fields = new Object[]{"A", "B", "C"};
        errorPrinted = false;
    }

    private void setErrorPrinted(boolean value){
        errorPrinted = value;
    }

    private void removeField(int fieldNum) {
        if (fieldNum >= 0 && fieldNum < getNumFields()) {
            for (int i = fieldNum; i < getNumFields() - 1; i++) {
                setField(i, getField(i + 1));
            }
            removeLastField();
        } else {
            setErrorPrinted(true);
        }
    }

    @Test
    public void testRemoveField_InvalidIndexNegative() {
        resetFields();
        removeField(-1);
        assertTrue(errorPrinted);
        assertArrayEquals(new Object[]{"A", "B", "C"}, fields);
        assertEquals(3, numFields);
    }

    @Test
    public void testRemoveField_InvalidIndexTooHigh() {
        resetFields();
        removeField(3);
        assertTrue(errorPrinted);
        assertArrayEquals(new Object[]{"A", "B", "C"}, fields);
        assertEquals(3, numFields);
    }

    @Test
    public void testRemoveField_FirstElement() {
        resetFields();
        removeField(0);
        assertFalse(errorPrinted);
        assertArrayEquals(new Object[]{"B", "C", null}, fields);
        assertEquals(2, numFields);
    }

    @Test
    public void testRemoveField_MiddleElement() {
        resetFields();
        removeField(1);
        assertFalse(errorPrinted);
        assertArrayEquals(new Object[]{"A", "C", null}, fields);
        assertEquals(2, numFields);
    }

    @Test
    public void testRemoveField_LastElement() {
        resetFields();
        removeField(2);
        assertFalse(errorPrinted);
        assertArrayEquals(new Object[]{"A", "B", null}, fields);
        assertEquals(2, numFields);
    }

    @Test
    public void testRemoveField_OneElement() {
        numFields = 1;
        fields = new Object[]{"A"};
        removeField(0);
        assertFalse(errorPrinted);
        assertArrayEquals(new Object[]{null}, fields);
        assertEquals(0, numFields);
    }
}
