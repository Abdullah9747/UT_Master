import java.sql.Types;
import java.util.Properties;
import org.junit.Test;
import static org.junit.Assert.*;

public class TypeMappingTest {

    @Test
    public void testCase1() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 1, 0);
        assertEquals("java.lang.Boolean", result);
    }

    @Test
    public void testCase2() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 2, 0);
        assertEquals("java.lang.Byte", result);
    }

    @Test
    public void testCase3() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 4, 0);
        assertEquals("java.lang.Short", result);
    }

    @Test
    public void testCase4() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 9, 0);
        assertEquals("java.lang.Integer", result);
    }

    @Test
    public void testCase5() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 18, 0);
        assertEquals("java.lang.Long", result);
    }

    @Test
    public void testCase6() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 19, 0);
        assertEquals("java.math.BigDecimal", result);
    }

    @Test
    public void testCase7() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.NUMERIC, 1, 0);
        assertEquals("java.lang.Boolean", result);
    }

    @Test
    public void testCase8() {
        Properties preferredJavaTypeForSqlType = new Properties();
        preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.INTEGER), "java.lang.Integer");
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.INTEGER, 10, 0);
        assertEquals("java.lang.Integer", result);
    }

    @Test
    public void testCase9() {
        Properties preferredJavaTypeForSqlType = new Properties();
        preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.VARCHAR), "java.lang.String");
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.VARCHAR, 255, 0);
        assertEquals("java.lang.String", result);
    }

    @Test
    public void testCase10() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.OTHER, 0, 0);
        assertEquals("java.lang.Object", result);
    }

    @Test
    public void testCase11() {
        Properties preferredJavaTypeForSqlType = new Properties();
        preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.DECIMAL), "java.math.BigDecimal");
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.DECIMAL, 10, 2);
        assertEquals("java.math.BigDecimal", result);
    }

    @Test
    public void testCase12() {
        Properties preferredJavaTypeForSqlType = new Properties();
        preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.NUMERIC), "java.math.BigDecimal");
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.NUMERIC, 10, 2);
        assertEquals("java.math.BigDecimal", result);
    }

    @Test
    public void testCase13() {
        Properties preferredJavaTypeForSqlType = new Properties();
        SqlTypeMapper mapper = new SqlTypeMapper(preferredJavaTypeForSqlType);
        String result = mapper.getPreferredJavaType(Types.NULL, 0, 0);
        assertEquals("java.lang.Object", result);
    }
}

class SqlTypeMapper {
    private Properties _preferredJavaTypeForSqlType;

    public SqlTypeMapper(Properties preferredJavaTypeForSqlType) {
        this._preferredJavaTypeForSqlType = preferredJavaTypeForSqlType;
    }

    public String getPreferredJavaType(int sqlType, int size, int decimalDigits) {
        if ((sqlType == Types.DECIMAL || sqlType == Types.NUMERIC)
                && decimalDigits == 0) {
            if (size == 1) {
                return "java.lang.Boolean";
            } else if (size < 3) {
                return "java.lang.Byte";
            } else if (size < 5) {
                return "java.lang.Short";
            } else if (size < 10) {
                return "java.lang.Integer";
            } else if (size < 19) {
                return "java.lang.Long";
            } else {
                return "java.math.BigDecimal";
            }
        }
        String result = _preferredJavaTypeForSqlType.getProperty(String.valueOf(sqlType));
        if (result == null) {
            result = "java.lang.Object";
        }
        return result;
    }

    private static Properties _preferredJavaTypeForSqlType = new Properties();
    static{
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.BOOLEAN), "java.lang.Boolean");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.CHAR), "java.lang.String");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.VARCHAR), "java.lang.String");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.LONGVARCHAR), "java.lang.String");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.CLOB), "java.sql.Clob");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.TINYINT), "java.lang.Byte");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.SMALLINT), "java.lang.Short");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.INTEGER), "java.lang.Integer");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.BIGINT), "java.lang.Long");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.REAL), "java.lang.Float");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.FLOAT), "java.lang.Double");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.DOUBLE), "java.lang.Double");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.DATE), "java.sql.Date");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.TIME), "java.sql.Time");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.TIMESTAMP), "java.sql.Timestamp");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.BINARY), "byte[]");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.VARBINARY), "byte[]");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.LONGVARBINARY), "byte[]");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.BLOB), "java.sql.Blob");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.REF), "java.sql.Ref");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.STRUCT), "java.lang.Object");
        _preferredJavaTypeForSqlType.setProperty(String.valueOf(Types.JAVA_OBJECT), "java.lang.Object");
    }
}
