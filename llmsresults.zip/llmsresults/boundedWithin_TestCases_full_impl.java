import org.junit.Test;
import static org.junit.Assert.*;

public class BoundedWithinTest {

    @Test
    public void testCase1() {
        assertFalse(BoundedWithin.boundedWithin(Double.NaN, Double.NaN, 5.0, 1.0));
    }

    @Test
    public void testCase2() {
        assertFalse(BoundedWithin.boundedWithin(10.0, 20.0, Double.NaN, 1.0));
    }

    @Test
    public void testCase3() {
        assertTrue(BoundedWithin.boundedWithin(Double.NaN, 20.0, 15.0, 1.0));
    }

    @Test
    public void testCase4() {
        assertFalse(BoundedWithin.boundedWithin(Double.NaN, 20.0, 22.0, 1.0));
    }

    @Test
    public void testCase5() {
        assertTrue(BoundedWithin.boundedWithin(10.0, Double.NaN, 15.0, 1.0));
    }

    @Test
    public void testCase6() {
        assertFalse(BoundedWithin.boundedWithin(10.0, Double.NaN, 8.0, 1.0));
    }

    @Test
    public void testCase7() {
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 15.0, 1.0));
    }

    @Test
    public void testCase8() {
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 9.0, 1.0));
    }

    @Test
    public void testCase9() {
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 21.0, 1.0));
    }

    @Test
    public void testCase10() {
        assertFalse(BoundedWithin.boundedWithin(10.0, 20.0, 7.0, 1.0));
    }

    @Test
    public void testCase11() {
        assertFalse(BoundedWithin.boundedWithin(10.0, 20.0, 23.0, 1.0));
    }
}
