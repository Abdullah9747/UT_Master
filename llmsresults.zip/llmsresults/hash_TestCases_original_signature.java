import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class HashTest {

    @Test
    public void testHashPositive() {
        assertEquals(165, hash(10, 5));
    }

    @Test
    public void testHashZero() {
        assertEquals(0, hash(0, 0));
    }

    @Test
    public void testHashNegativeData() {
        assertEquals(305, hash(-5, 10));
    }

    @Test
    public void testHashNegativeSeed() {
        assertEquals(-305, hash(5, -10));
    }

    @Test
    public void testHashMaxValue() {
        int max = Integer.MAX_VALUE;
        int expected = 31 * max + max;
        assertEquals(expected, hash(max, max));
    }

    int hash(int data, int seed) {
        int result = seed;
        result = 31 * result + data;
        return result;
    }
}
