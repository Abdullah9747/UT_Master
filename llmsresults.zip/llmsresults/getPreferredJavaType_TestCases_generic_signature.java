import org.junit.Test;
import static org.junit.Assert.*;

public class WPDUBcohQTTest {

    @Test
    public void testEmptyString() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("", obj.WPDUBcohQT(0, 0, 1));
    }

    @Test
    public void testSingleCharacter() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("A", obj.WPDUBcohQT(1, 0, 26));
    }

    @Test
    public void testMultipleCharactersWithinAlphabet() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("ABC", obj.WPDUBcohQT(3, 0, 26));
    }

    @Test
    public void testOffsetAndAlphabet() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("BCD", obj.WPDUBcohQT(3, 1, 26));
    }

    @Test
    public void testWrappingAroundAlphabet() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("XYZ", obj.WPDUBcohQT(3, 23, 26));
    }

    @Test
    public void testLargeOffsetAndModulus() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("A", obj.WPDUBcohQT(1, 26, 26));
    }

    @Test
    public void testDifferentModulus() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("BB", obj.WPDUBcohQT(2, 0, 2));
    }

    @Test
    public void testLargeValues() {
        WPDUBcohQT obj = new WPDUBcohQT();
        assertEquals("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB", obj.WPDUBcohQT(200, 0, 2));
    }

    class WPDUBcohQT {
        String WPDUBcohQT(int MfQWPbRyBu, int DExtjFeHIL, int oGIIDGjvqo) {
            String yzZzHjNqg = "";
            for (int i = 0; i < MfQWPbRyBu; i++) {
                yzZzHjNqg += (char) ((DExtjFeHIL + i) % oGIIDGjvqo + 65);
            }
            return yzZzHjNqg;
        }
    }
}
