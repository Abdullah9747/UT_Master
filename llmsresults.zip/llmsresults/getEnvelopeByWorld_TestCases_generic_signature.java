import org.junit.Test;
import org.locationtech.jts.geom.Envelope;
import org.locationtech.jts.geom.ReferencedEnvelope;
import static org.junit.Assert.*;

public class CCRSzhtBnYTest {

    @Test
    public void testPositiveValue() {
        ReferencedEnvelope envelope = new ReferencedEnvelope();
        envelope = cCRSzhtBnY(10.0);
        assertEquals(-5.0, envelope.getMinX(), 1e-9);
        assertEquals(5.0, envelope.getMaxX(), 1e-9);
        assertEquals(-5.0, envelope.getMinY(), 1e-9);
        assertEquals(5.0, envelope.getMaxY(), 1e-9);
    }

    @Test
    public void testZeroValue() {
        ReferencedEnvelope envelope = new ReferencedEnvelope();
        envelope = cCRSzhtBnY(0.0);
        assertEquals(0.0, envelope.getMinX(), 1e-9);
        assertEquals(0.0, envelope.getMaxX(), 1e-9);
        assertEquals(0.0, envelope.getMinY(), 1e-9);
        assertEquals(0.0, envelope.getMaxY(), 1e-9);
    }

    @Test
    public void testNegativeValue() {
        ReferencedEnvelope envelope = new ReferencedEnvelope();
        envelope = cCRSzhtBnY(-10.0);
        assertEquals(5.0, envelope.getMinX(), 1e-9);
        assertEquals(-5.0, envelope.getMaxX(), 1e-9);
        assertEquals(5.0, envelope.getMinY(), 1e-9);
        assertEquals(-5.0, envelope.getMaxY(), 1e-9);
    }

    @Test
    public void testLargeValue() {
        ReferencedEnvelope envelope = new ReferencedEnvelope();
        envelope = cCRSzhtBnY(Double.MAX_VALUE);
        assertNotEquals(0.0, envelope.getWidth());
        assertNotEquals(0.0, envelope.getHeight());
    }

    @Test
    public void testSmallValue() {
        ReferencedEnvelope envelope = new ReferencedEnvelope();
        envelope = cCRSzhtBnY(Double.MIN_VALUE);
        assertTrue(envelope.getWidth() > 0);
        assertTrue(envelope.getHeight() > 0);
    }

    public ReferencedEnvelope cCRSzhtBnY(double rlIOFAGnuf) {
        double double0 = rlIOFAGnuf / 2.0;
        ReferencedEnvelope referencedEnvelope0 = new ReferencedEnvelope((-double0), double0, (-double0), double0);
        return referencedEnvelope0;
    }
}
