import org.junit.Test;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import static org.junit.Assert.*;

public class SolutionTest {

    @Test
    public void testBasicRange() {
        Solution sol = new Solution();
        Pattern pattern = sol.range('a', 'z');
        Matcher matcher = pattern.matcher("b");
        assertTrue(matcher.find());

        matcher = pattern.matcher("A");
        assertFalse(matcher.find());
    }

    @Test
    public void testNumericRange() {
        Solution sol = new Solution();
        Pattern pattern = sol.range('0', '9');
        Matcher matcher = pattern.matcher("5");
        assertTrue(matcher.find());

        matcher = pattern.matcher("a");
        assertFalse(matcher.find());
    }

    @Test
    public void testSameCharacterRange() {
        Solution sol = new Solution();
        Pattern pattern = sol.range('x', 'x');
        Matcher matcher = pattern.matcher("x");
        assertTrue(matcher.find());

        matcher = pattern.matcher("y");
        assertFalse(matcher.find());
    }

    @Test
    public void testSpecialCharacterRange() {
        Solution sol = new Solution();
        Pattern pattern = sol.range('!', '/');
        Matcher matcher = pattern.matcher("$");
        assertTrue(matcher.find());

        matcher = pattern.matcher("a");
        assertFalse(matcher.find());
    }

    @Test
    public void testReversedRange() {
        Solution sol = new Solution();
        Pattern pattern = sol.range('z', 'a');

        Matcher matcher = pattern.matcher("z");
        assertFalse(matcher.find());

        matcher = pattern.matcher("a");
        assertFalse(matcher.find());

        matcher = pattern.matcher("-");
        assertFalse(matcher.find());

    }
}
