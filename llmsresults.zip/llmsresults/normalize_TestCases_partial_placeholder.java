import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class NormalizeTest {

    @Test
    public void testNormalize_VTBkuAtpKU_is_0() {
        assertEquals(5, normalize(5, 0));
    }

    @Test
    public void testNormalize_VTBkuAtpKU_is_not_0() {
        assertEquals(1, normalize(10, 3));
    }

    private int normalize(int IROgpYyGdG, int VTBkuAtpKU) {
        if (VTBkuAtpKU == 0) {
            return IROgpYyGdG;
        } else {
            return IROgpYyGdG % VTBkuAtpKU;
        }
    }
}
