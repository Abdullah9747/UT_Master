import org.junit.Test;
import static org.junit.Assert.*;

public class BoundedWithinTest {

    @Test
    public void testInvalidBounds() {
        // lowerBound > upperBound
        assertFalse(BoundedWithin.boundedWithin(20.0, 10.0, 15.0, 1.0));
    }

    @Test
    public void testValueTooLow() {
        // value < lowerBound - margin
        assertFalse(BoundedWithin.boundedWithin(10.0, 20.0, 7.0, 2.0));
    }

    @Test
    public void testValueTooHigh() {
        // value > upperBound + margin
        assertFalse(BoundedWithin.boundedWithin(10.0, 20.0, 23.0, 2.0));
    }

    @Test
    public void testValueWithinBounds() {
        // All if conditions are false, leading to return true
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 15.0, 2.0));
    }

    @Test
    public void testValueAtLowerBoundMinusMargin() {
        //Value is equal to the lower bound minus the margin
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 8.0, 2.0));
    }

    @Test
    public void testValueAtUpperBoundPlusMargin() {
        //Value is equal to the upper bound plus the margin
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 22.0, 2.0));
    }

    @Test
    public void testValueAtLowerBound() {
        //Value is equal to the lower bound
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 10.0, 2.0));
    }

    @Test
    public void testValueAtUpperBound() {
        //Value is equal to the upper bound
        assertTrue(BoundedWithin.boundedWithin(10.0, 20.0, 20.0, 2.0));
    }

    static class BoundedWithin {  // Inner class to define the method
        static boolean boundedWithin(double lowerBound, double upperBound, double value, double margin) {
            if (lowerBound > upperBound) {
                return false;
            }

            if (value < lowerBound - margin) {
                return false;
            }

            if (value > upperBound + margin) {
                return false;
            }

            return true;
        }
    }
}
