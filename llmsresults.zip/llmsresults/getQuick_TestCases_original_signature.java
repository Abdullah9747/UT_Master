import org.junit.Test;
import static org.junit.Assert.*;

public class GetQuickTest {

    private static class TestClass {
        private double[] values;
        private int size;

        public TestClass(double[] values, int size) {
            this.values = values;
            this.size = size;
        }

        public double getQuick(int index) {
            if (index < 0 || index >= size) {
                throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
            }
            return values[index];
        }
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetQuick_negativeIndex() {
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        int size = 5;
        TestClass testObject = new TestClass(values, size);
        testObject.getQuick(-1);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testGetQuick_indexEqualsSize() {
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        int size = 5;
        TestClass testObject = new TestClass(values, size);
        testObject.getQuick(5);
    }

    @Test
    public void testGetQuick_validIndex() {
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        int size = 5;
        TestClass testObject = new TestClass(values, size);
        double result = testObject.getQuick(2);
        assertEquals(3.0, result, 0.00001);
    }
}
