import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.sql.Types;

public class TypeConverterTest {

    @Test
    public void testGetPreferredJavaType_BOOLEAN() {
        assertEquals("java.lang.Boolean", TypeConverter.getPreferredJavaType(Types.BOOLEAN, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_BIT() {
        assertEquals("java.lang.Boolean", TypeConverter.getPreferredJavaType(Types.BIT, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_TINYINT() {
        assertEquals("java.lang.Byte", TypeConverter.getPreferredJavaType(Types.TINYINT, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_SMALLINT() {
        assertEquals("java.lang.Short", TypeConverter.getPreferredJavaType(Types.SMALLINT, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_INTEGER() {
        assertEquals("java.lang.Integer", TypeConverter.getPreferredJavaType(Types.INTEGER, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_BIGINT() {
        assertEquals("java.lang.Long", TypeConverter.getPreferredJavaType(Types.BIGINT, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_REAL() {
        assertEquals("java.lang.Float", TypeConverter.getPreferredJavaType(Types.REAL, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_FLOAT() {
        assertEquals("java.lang.Double", TypeConverter.getPreferredJavaType(Types.FLOAT, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_DOUBLE() {
        assertEquals("java.lang.Double", TypeConverter.getPreferredJavaType(Types.DOUBLE, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_NUMERIC() {
        assertEquals("java.math.BigDecimal", TypeConverter.getPreferredJavaType(Types.NUMERIC, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_DECIMAL() {
        assertEquals("java.math.BigDecimal", TypeConverter.getPreferredJavaType(Types.DECIMAL, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_CHAR() {
        assertEquals("java.lang.String", TypeConverter.getPreferredJavaType(Types.CHAR, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_VARCHAR() {
        assertEquals("java.lang.String", TypeConverter.getPreferredJavaType(Types.VARCHAR, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_LONGVARCHAR() {
        assertEquals("java.lang.String", TypeConverter.getPreferredJavaType(Types.LONGVARCHAR, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_DATE() {
        assertEquals("java.sql.Date", TypeConverter.getPreferredJavaType(Types.DATE, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_TIME() {
        assertEquals("java.sql.Time", TypeConverter.getPreferredJavaType(Types.TIME, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_TIMESTAMP() {
        assertEquals("java.sql.Timestamp", TypeConverter.getPreferredJavaType(Types.TIMESTAMP, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_BINARY() {
        assertEquals("byte[]", TypeConverter.getPreferredJavaType(Types.BINARY, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_VARBINARY() {
        assertEquals("byte[]", TypeConverter.getPreferredJavaType(Types.VARBINARY, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_LONGVARBINARY() {
        assertEquals("byte[]", TypeConverter.getPreferredJavaType(Types.LONGVARBINARY, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_BLOB() {
        assertEquals("java.sql.Blob", TypeConverter.getPreferredJavaType(Types.BLOB, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_CLOB() {
        assertEquals("java.sql.Clob", TypeConverter.getPreferredJavaType(Types.CLOB, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_REF() {
        assertEquals("java.sql.Ref", TypeConverter.getPreferredJavaType(Types.REF, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_STRUCT() {
        assertEquals("java.sql.Struct", TypeConverter.getPreferredJavaType(Types.STRUCT, 0, 0));
    }

    @Test
    public void testGetPreferredJavaType_OTHER() {
        assertEquals("java.lang.Object", TypeConverter.getPreferredJavaType(-999, 0, 0));
    }
}
