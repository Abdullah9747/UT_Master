import org.junit.Test;
import static org.junit.Assert.*;

public class NormalizeTest {

    @Test
    public void testNormalize1() {
        assertEquals(-3, Solution.normalize(5, 3));
    }

    @Test
    public void testNormalize2() {
        assertEquals(2, Solution.normalize(2, 3));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNormalize3() {
        Solution.normalize(256, 8);
    }

    @Test
    public void testNormalize4() {
        assertEquals(0, Solution.normalize(0, 3));
    }

    @Test
    public void testNormalize5() {
        assertEquals(-1, Solution.normalize(7, 3));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNormalize6() {
        Solution.normalize(-1, 3);
    }
}
